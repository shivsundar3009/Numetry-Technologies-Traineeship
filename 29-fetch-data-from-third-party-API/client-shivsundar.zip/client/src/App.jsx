import React from 'react'
import SearchUser from './components/SearchUser'

function App() {
  return (


    <>
    
    <SearchUser/>
    </>
  )
}

export default App